<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sports Centre Login</title>
    <link rel="stylesheet" href="../../../public/assets/styles/style.css">
    <link rel="stylesheet" href="../../../public/assets/styles/registration.css">
    <link rel="stylesheet" href="../../../public/assets/styles/login.css">
</head>
<body>

    <?php include '../../../includes/header.php'; ?>
    <?php include '../../../includes/navbar.php'; ?>
    <?php
    require_once '../../../config/Database.php';

    $database = new Database();
    $conn = $database->conn;

    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $email = $_POST['email'];
        $password = $_POST['psw'];

        $stmt = $conn->prepare("SELECT user_id, role, password FROM tbl_users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $stmt->bind_result($user_id, $role, $hashed_password);
            $stmt->fetch();

            if (password_verify($password, $hashed_password)) {
                $_SESSION["loggedin"] = true;
                $_SESSION["email"] = $email;
                $_SESSION["user_id"] = $user_id;
                $_SESSION["role"] = $role;
                
                header("location: ../dashboard/dashboard.php");
                exit;
            } else {
                echo "<p>Incorrect password.</p>";
            }
        } else {
            echo "<p>No account found with that email.</p>";
        }

        $stmt->close();
    }
    ?>

    <main>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <h2>Login Form</h2>
            <div id="form-wrapper-main" class="container">
                <div class="form-group">
                    <label for="email"><b>Email</b></label>
                    <input type="email" placeholder="Enter Email" name="email" required>
                </div>

                <div class="form-group">
                    <label for="psw"><b>Password</b></label>
                    <input type="password" placeholder="Enter Password" name="psw" required>
                </div>
                
                <button type="submit">Login</button>
            </div>

            <div id="login-bottom-container">
                <p>Forgot password?<a href="#"><strong> Click Here</strong></a></p>
                <footer id="login-footer">
                    <p>Not a member?<a href="registration.php"><strong> Register Here</strong></a></p>
                </footer>
            </div>
        </form>
    </main>

    <?php include '../../../includes/footer.php'; ?>
</body>
</html>
