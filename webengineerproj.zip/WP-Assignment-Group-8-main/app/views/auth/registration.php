<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
    header("location: ../dashboard/dashboard.php");
    exit;
}

require_once '../../models/User.php';
require_once '../../../config/database.php';

$db = new Database();
$conn = $db->conn;

$nameErr = $surnameErr = $emailErr = $emailAgainErr = $passwordErr = $passwordAgainErr = $emailMatchErr = $passwordMatchErr = "";
$name = $surname = $email = $emailAgain = $password = $passwordAgain = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["email"])) {
        $emailErr = "Email is required";
    } else {
        $email = test_input($_POST["email"]);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Invalid email format";
        }
        $checkEmailQuery = "SELECT * FROM tbl_users WHERE email = ?";
        $stmt = $conn->prepare($checkEmailQuery);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $emailErr = "Email is already registered";
        }
    }

    if (empty($_POST["password"])) {
        $passwordErr = "Password is required";
    } else {
        $password = test_input($_POST["password"]);
    }

    if (empty($nameErr) && empty($surnameErr) && empty($emailErr) && empty($emailAgainErr) && empty($passwordErr) && empty($passwordAgainErr)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $insertUserQuery = "INSERT INTO tbl_users (name, surname, email, password, role) VALUES (?, ?, ?, ?, ?)";
        $role = "user";
        $stmt = $conn->prepare($insertUserQuery);
        $stmt->bind_param("sssss", $name, $surname, $email, $hashedPassword, $role);
        if ($stmt->execute()) {
            header("location: login.php");
            exit;
        } else {
            echo "Error inserting user into the database: " . $conn->error;
        }
    }
}

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sports Centre Registration Page</title>
    <link rel="stylesheet" href="../../../public/assets/styles/style.css">
    <link rel="stylesheet" href="../../../public/assets/styles/registration.css">
</head>
<body>
    <main>
        <?php include '../../../includes/header.php'; ?>
        <?php include '../../../includes/navbar.php'; ?>

        <form id="signup-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
            <h1>Sign Up</h1>
            <div id="form-wrapper-main">
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" name="name" id="name" value="<?php echo $name;?>" required>
                    <span class="error"><?php echo $nameErr;?></span>
                </div>
                <div class="form-group">
                    <label for="surname">Surname:</label>
                    <input type="text" name="surname" id="surname" value="<?php echo $surname;?>" required>
                    <span class="error"><?php echo $surnameErr;?></span>
                </div>

                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" name="email" id="email" value="<?php echo $email;?>" required>
                    <span class="error"><?php echo $emailErr;?></span>
                </div>
                <div class="form-group">
                    <label for="emailAgain">Email Again:</label>
                    <input type="email" name="emailAgain" id="email-again" value="<?php echo $emailAgain;?>" required>
                    <span class="error"><?php echo $emailAgainErr;?></span>
                    <span class="error"><?php echo $emailMatchErr;?></span>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" name="password" id="password" value="<?php echo $password; ?>" required>
                    <span class="error"><?php echo $passwordErr;?></span>
                </div>
                <div class="form-group">
                    <label for="passwordAgain">Password Again:</label>
                    <input type="password" name="passwordAgain" id="password-again" value="<?php echo $passwordAgain; ?>" required>
                    <span class="error"><?php echo $passwordAgainErr;?></span>
                    <span class="error"><?php echo $passwordMatchErr;?></span>
                </div>
                
                <button type="submit">Register</button>
            </div>
            <footer>Already a member? <a href="login.php">Login here</a></footer>
        </form>
    </main>

    <?php include '../../../includes/footer.php'; ?>
</body>
</html>
