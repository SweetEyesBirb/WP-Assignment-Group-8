<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search_results</title>
</head>
<body>
    <h2>Search_results</h2>
    <form action="search.php" method="GET">
        <label for="search">Search:</label>
        <input type="text" id="search" name="query" placeholder="Enter your search term">
        <button type="submit">Search</button>
    </form>
</body>
</html>
