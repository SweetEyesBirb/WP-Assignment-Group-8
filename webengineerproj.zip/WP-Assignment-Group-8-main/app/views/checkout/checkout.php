<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Sports Centre Checkout</title>

    <link rel="stylesheet" href="../../../public/assets/styles/style.css">

</head>

<body>
  <?php include '../../../includes/header.php'; ?>
  <?php include '../../../includes/navbar.php'; ?>

  <main>

    <h1>Checkout Process</h1>
    <h2>(Not going to be implemented - Not Required)</h2>

  </main>

  <?php include '../../../includes/footer.php'; ?>

</body>
</html>