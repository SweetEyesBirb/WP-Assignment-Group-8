<?php
session_start();

if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: login.php");
    exit;
}

if (!isset($_SESSION["user_id"])) {
    echo "User ID not set in session.";
    exit;
}

include '../../../includes/header.php';
include '../../../includes/navbar.php';
require_once '../../../config/database.php';

$db = new Database();
$conn = $db->conn;
$user_id = $_SESSION['user_id'];

function getAttendeesCount($class_id, $conn) {
    $query = "SELECT COUNT(*) AS attendee_count FROM tbl_bookings WHERE class_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $class_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['attendee_count'];
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['create_class'])) {
    $class_name = $_POST['class_name'];
    $date = $_POST['date'];
    $time_start = $_POST['time_start'];
    $time_end = $_POST['time_end'];
    $price = $_POST['price'];

    $createQuery = "INSERT INTO tbl_classes (class_name, date, time_start, time_end, price) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($createQuery);
    $stmt->bind_param("ssssd", $class_name, $date, $time_start, $time_end, $price);
    $stmt->execute();
}

if (isset($_GET['action']) && isset($_GET['class_id'])) {
    $class_id = $_GET['class_id'];

    switch($_GET['action']) {
        case 'join':
            $joinQuery = "INSERT INTO tbl_bookings (user_id, class_id) VALUES (?, ?)";
            $stmt = $conn->prepare($joinQuery);
            $stmt->bind_param("ii", $user_id, $class_id);
            $stmt->execute();
            break;

        case 'leave':
            $leaveQuery = "DELETE FROM tbl_bookings WHERE class_id = ? AND user_id = ?";
            $stmt = $conn->prepare($leaveQuery);
            $stmt->bind_param("ii", $class_id, $user_id);
            $stmt->execute();
            break;

        case 'delete':
            $deleteBookingsQuery = "DELETE FROM tbl_bookings WHERE class_id = ?";
            $stmt = $conn->prepare($deleteBookingsQuery);
            $stmt->bind_param("i", $class_id);
            $stmt->execute();

            $deleteClassQuery = "DELETE FROM tbl_classes WHERE class_id = ?";
            $stmt = $conn->prepare($deleteClassQuery);
            $stmt->bind_param("i", $class_id);
            $stmt->execute();
            break;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="../../../public/assets/styles/style.css">
    <link rel="stylesheet" href="../../../public/assets/styles/dashboard.css">
    <style>
        main {
            text-align: center;
        }
        table {
            margin-top: 10px;
            margin-bottom: 20px;
            margin-left: auto;
            margin-right: auto;
            border-collapse: collapse;
            width: 80%;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
            text-align: center;
        }
    </style>
</head>
<body>
<main>
    <section id="dashboard">
        <h1>Dashboard</h1>
        <p>Welcome to your dashboard, <?php echo htmlspecialchars($_SESSION["email"]); ?>!</p>
        <table>
            <thead>
                <tr>
                    <th style="text-align: center;">Class ID</th>
                    <th style="text-align: center;">Class Name</th>
                    <th style="text-align: center;">Date</th>
                    <th style="text-align: center;">Time</th>
                    <th style="text-align: center;">Price</th>
                    <th style="text-align: center;">Actions</th>
                    <th style="text-align: center;">Attendees</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = "SELECT * FROM tbl_classes";
                $result = $conn->query($query);
                while ($row = $result->fetch_assoc()) {
                    $class_id = $row['class_id'];
                    $attendee_count = getAttendeesCount($class_id, $conn);

                    echo "<tr>";
                    echo "<td>" . $class_id . "</td>";
                    echo "<td>" . $row['class_name'] . "</td>";
                    echo "<td>" . $row['date'] . "</td>";
                    echo "<td>" . $row['time_start'] . " - " . $row['time_end'] . "</td>";
                    echo "<td>" . $row['price'] . "</td>";
                    echo "<td>";

                    $userJoined = false;
                    $joinQuery = "SELECT * FROM tbl_bookings WHERE user_id = ? AND class_id = ?";
                    $stmt = $conn->prepare($joinQuery);
                    $stmt->bind_param("ii", $user_id, $class_id);
                    $stmt->execute();
                    $joinResult = $stmt->get_result();
                    if ($joinResult->num_rows > 0) {
                        $userJoined = true;
                    }

                    if ($userJoined) {
                        echo "<a href='?action=leave&class_id=" . $row['class_id'] . "'>Leave</a>";
                    } else {
                        echo "<a href='?action=join&class_id=" . $row['class_id'] . "'>Join</a>";
                    }

                    if ($_SESSION["role"] == "admin") {
                        echo "<a href='?action=delete&class_id=" . $row['class_id'] . "'>Delete</a>";
                    }
                    echo "</td>";
                    echo "<td>" . $attendee_count . "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>

        <?php if ($_SESSION["role"] == "admin"): ?>
            <section id="create-class">
                <h2>Create New Class</h2>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <div class="form-group">
                        <label for="class_name">Class Name</label>
                        <input type="text" name="class_name" required>
                    </div>
                    <div class="form-group">
                        <label for="date">Date</label>
                        <input type="date" name="date" required>
                    </div>
                    <div class="form-group">
                        <label for="time_start">Start Time</label>
                        <input type="time" name="time_start" required>
                    </div>
                    <div class="form-group">
                        <label for="time_end">End Time</label>
                        <input type="time" name="time_end" required>
                    </div>
                    <div class="form-group">
                        <label for="price">Price</label>
                        <input type="number" name="price" min="0.01" step="0.01" required>
                    </div>
                    <button type="submit" name="create_class">Create Class</button>
                </form>
            </section>
            <section id="edit-class">
                <h2>Edit Class</h2>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <div class="form-group">
                        <label for="class_id">Class ID</label>
                        <input type="text" name="class_id" required>
                    </div>
                    <div class="form-group">
                        <label for="class_name">Class Name</label>
                        <input type="text" name="class_name" required>
                    </div>
                    <div class="form-group">
                        <label for="date">Date</label>
                        <input type="date" name="date" required>
                    </div>
                    <div class="form-group">
                        <label for="time_start">Start Time</label>
                        <input type="time" name="time_start" required>
                    </div>
                    <div class="form-group">
                        <label for="time_end">End Time</label>
                        <input type="time" name="time_end" required>
                    </div>
                    <div class="form-group">
                        <label for="price">Price</label>
                        <input type="number" name="price" min="0.01" step="0.01" required>
                    </div>
                    <button type="submit" name="update_class">Update Class</button>
                </form>
            </section>
        <?php endif; ?>
    </section>
</main>
<?php include '../../../includes/footer.php'; ?>
</body>
</html>
