<?php
session_start();

if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["role"] !== "admin") {
    header("location: login.php");
    exit;
}

include '../../../includes/header.php';
include '../../../includes/navbar.php';

require_once '../../../config/database.php';

$db = new Database();
$conn = $db->conn;

if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    if ($user_id == $_SESSION["user_id"] || $user_id == 1) {
        header("location: login.php");
        exit;
    }

    $deleteBookingsQuery = "DELETE FROM tbl_bookings WHERE user_id = ?";
    $stmt = $conn->prepare($deleteBookingsQuery);
    $stmt->bind_param("i", $user_id);

    if ($stmt->execute()) {
        $deleteUserQuery = "DELETE FROM tbl_users WHERE user_id = ?";
        $stmt = $conn->prepare($deleteUserQuery);
        $stmt->bind_param("i", $user_id);

        if ($stmt->execute()) {
            echo "<p>User deleted successfully.</p>";
        } else {
            echo "<p>Error deleting user: " . $conn->error . "</p>";
        }
    } else {
        echo "<p>Error deleting bookings for the user: " . $conn->error . "</p>";
    }
}

$usersQuery = "SELECT * FROM tbl_users";
$usersResult = $conn->query($usersQuery);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sports Centre Admin</title>
    <link rel="stylesheet" href="../../../public/assets/styles/style.css">
    <link rel="stylesheet" href="../../../public/assets/styles/registration.css">
    <link rel="stylesheet" href="../../../public/assets/styles/admin.css">
</head>

<body>
    <main>
        <h1>Admin Panel</h1>
        <p>Welcome, <?php echo htmlspecialchars($_SESSION["email"]); ?> (Admin)!</p>
        <h2>Users</h2>
        <table>
            <thead>
                <tr>
                    <th>User ID</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Action</th>
                    <th>Edit</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($usersResult->num_rows > 0) {
                    while ($user = $usersResult->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $user['user_id'] . "</td>";
                        echo "<td>" . $user['email'] . "</td>";
                        echo "<td>" . $user['role'] . "</td>";
                        if ($user['user_id'] != 1 && $user['user_id'] != $_SESSION["user_id"]) {
                            echo "<td><a href='?action=delete&user_id=" . $user['user_id'] . "'>Delete</a></td>";
                        } else {
                            echo "<td>Not Allowed</td>";
                        }
                        echo "<td><a href='edit_user.php?user_id=" . $user['user_id'] . "'>Edit</a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No users found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </main>
    <?php include '../../../includes/footer.php'; ?>
</body>

</html>
