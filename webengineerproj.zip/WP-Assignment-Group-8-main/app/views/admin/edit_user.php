<?php
session_start();

if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["role"] !== "admin") {
    header("location: login.php");
    exit;
}

require_once '../../../config/database.php';

$db = new Database();
$conn = $db->conn;

if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    $getUserQuery = "SELECT * FROM tbl_users WHERE user_id = ?";
    $stmt = $conn->prepare($getUserQuery);
    $stmt->bind_param("i", $user_id);

    if ($stmt->execute()) {
        $userResult = $stmt->get_result();
        if ($userResult->num_rows === 1) {
            $user = $userResult->fetch_assoc();
        } else {
            echo "User not found.";
            exit;
        }
    } else {
        echo "Error fetching user details: " . $conn->error;
        exit;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $newEmail = $_POST["email"];
    $newPassword = $_POST["password"];

    $updateUserQuery = "UPDATE tbl_users SET email = ?, password = ? WHERE user_id = ?";
    $stmt = $conn->prepare($updateUserQuery);
    $stmt->bind_param("ssi", $newEmail, $newPassword, $user_id);

    if ($stmt->execute()) {
        echo "<p>User details updated successfully.</p>";
    } else {
        echo "<p>Error updating user details: " . $conn->error . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User Details</title>
    <link rel="stylesheet" href="../../../public/assets/styles/style.css">
    <link rel="stylesheet" href="../../../public/assets/styles/registration.css">
</head>

<body>
    <?php include '../../../includes/header.php'; ?>
    <?php include '../../../includes/navbar.php'; ?>

    <form id="edit-user-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . "?user_id=" . $user_id;?>" method="post">
        <h1>Edit User Details</h1>
        <div id="form-wrapper-main">
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($user['email']);?>" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" name="password" id="password" value="<?php echo htmlspecialchars($user['password']);?>" required>
            </div>
            <button type="submit">Save Changes</button>
        </div>
    </form>

    <?php include '../../../includes/footer.php'; ?>
</body>

</html>
