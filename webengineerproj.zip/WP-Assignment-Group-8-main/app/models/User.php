<?php
require_once __DIR__ . '/../../config/Database.php';


class User {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    public function register($name, $surname, $email, $dob, $password) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $this->db->conn->prepare("INSERT INTO tbl_users (name, surname, email, dob, password, role) VALUES (?, ?, ?, ?, ?, ?)");
        $role = 'user'; // default role
        $stmt->bind_param("ssssss", $name, $surname, $email, $dob, $hashed_password, $role);
        $result = $stmt->execute();
        $stmt->close();
        return $result;
    }
}
?>
