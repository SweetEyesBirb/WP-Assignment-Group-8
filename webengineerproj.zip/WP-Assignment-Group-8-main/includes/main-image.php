<div id="main-image"> <!-- From Unsplash.com accessed on 20/10/2023 -->
    <div id="join-button">
        <a href="../../../app/views/general/membership.php">Join Now</a>
    </div>
</div>