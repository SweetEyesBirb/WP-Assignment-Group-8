<header>
    <div id="logo">
        <img src="logo.png" alt="Sports Centre Logo">
    </div>
    <div id="search-bar">
        <input type="text" placeholder="Search..." aria-label="Search Bar">
    </div>
    <div id="login-box">
        <?php
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
            echo '<a href="app/views/auth/login.php">Log In</a>';
        } else {
            echo '<a href="../../../app/views/auth/logout.php">Log Out</a>';
            echo '<a> (' . htmlspecialchars($_SESSION["email"]) . ')</a>';
        }
        ?>
    </div>
</header>
