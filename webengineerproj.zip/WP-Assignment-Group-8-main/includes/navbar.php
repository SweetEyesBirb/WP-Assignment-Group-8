<nav>
    <ul>
        <li><a href="../../../index.php">Home</a></li>
        <li><a href="../../../app/views/general/membership.php">Join</a></li>
        <li><a href="../../../app/views/general/info.php">Info</a></li>

        <?php
        if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true && isset($_SESSION["role"]) && $_SESSION["role"] === 'admin') {
            echo '<li><a href="../../../app/views/admin/admin.php">Admin Panel</a></li>';
        }
        ?>
    </ul>
</nav>
