<footer>
    <p>2023 Group 8 Assignment Sports Centre Website</p>
</footer>